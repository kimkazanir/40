
Bu proje, 3 deste ile oynanan 51 kart oyununun Flask tabanlı test sürümüdür.
Özellikler:
- Her oyuncuya 14 kart dağıtılır
- 2 oyunculu metin tabanlı test
- Kartlar otomatik olarak dizilir
